<?php
namespace App\Livewire\News;

use App\Models\County;
use App\Models\News;
use App\Models\Region;
use App\Models\Subcounty;
use Livewire\Component;

class WriteNews extends Component
{
    public $searchCounty = '';
    public $selectedCounty = '';
    public $searchConstituency = '';
    public $selectedConstituency = '';
    public $searchSubcounty = '';
    public $selectedSubcounty = '';

    public $counties = [];
    public $constituencies = [];
    public $subcounties = [];
    public $selectedConstituencyId = '';
    public $newsType='';
    public $title = '';
    public $content='';
    public $image=null;
    public $selectedSubcountyId='';
    public $selectedCountyId = '';


    public function createNews()
    {
        $this->validate([
            'title' => 'required|string|max:255',
            'content' => 'required',
            'newsType' => 'required',
            'image' => 'nullable|image|max:2048', // validate image
        ]);

        $news = new News();
        $news->title = $this->title;
        $news->content = $this->content;
        $news->type = $this->newsType;
        $news->county_id = $this->selectedCountyId;
        $news->region_id = $this->selectedCounty->region_id;
        $news->subcounty_id = $this->selectedSubcountyId;

        // handle image upload if exists
        if ($this->image) {
            $news->image = $this->image->store('news_images', 'public');
        }

        $news->save();

        // Optional: reset fields or show success message
        $this->reset(['title', 'content', 'newsType', 'image']);
        session()->flash('message', 'News created successfully!');
    }

    public function updatedSearchCounty()
    {

        $this->counties = !empty($this->searchCounty)
            ? County::where('name', 'like', '%' . $this->searchCounty . '%')->get()
            : [];

    }

    // public function updatedSearchConstituency()
    // {
    //     $this->constituencies = !empty($this->searchConstituency)
    //         ? Region::where('name', 'like', '%' . $this->searchConstituency . '%')->get()
    //         : [];
    // }

    public function selectConstituency($id,$name)
    {
        $this->selectedConstituencyId = $id;
        $this->selectedConstituency= $name;
        $this->subcounties = Subcounty::where('region_id', $id)->get();
        if ($this->subcounties->count() != 0) {
            $this->searchConstituency = '';
            $this->constituencies = [];
        }

    }

    // You can add additional logic here when a constituency is selected

    public function selectSubcounty($id,$name){
        $this->selectedSubcountyId = $id;
        $this->selectedSubcounty=$name;
         $this->subcounties = [];
    }

    public function selectCounty($id,$name)
    {
        $this->selectedCountyId = $id;
        $this->selectedCounty=$name;
        $this->constituencies = Region::where('county_id', $id)->get();

        $this->counties = [];
        $this->searchCounty = '';
    }


    // public function updatedSearchSubcounty()
    // {
    //     $this->subcounties = !empty($this->searchSubcounty)
    //         ? Subcounty::where('name', 'like', '%' . $this->searchSubcounty . '%')->get()
    //         : [];
    // }


    public function render()
    {
        $countys = County::all();

        return view('livewire.news.write-news', compact('countys'));
    }
}
