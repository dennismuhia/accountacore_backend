<div>
    {{-- Because she competes with no one, no one can compete with her. --}}
    <label for="subcounty">Subcounty</label>
    <input id="subcounty" type="text" wire:model.debounce.300ms="searchSubcounty"
     placeholder="Search for a subcounty..." class="w-3/4 px-4 py-2 border rounded" />
</div>
