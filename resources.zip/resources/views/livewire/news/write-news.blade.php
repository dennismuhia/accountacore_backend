<div class="p-4 sm:ml-64">
    <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700 mt-14">
        <div class="grid grid-cols-4 gap-4 mb-4">

            <form wire:submit.prevent="createNews" class="space-y-4">
                @csrf
            <div class="flex items-center justify-center h-24 gap-2 rounded-sm bg-gray-50 dark:bg-gray-800">
                <label for="newsType">News Type</label>
                <select name="newsType" wire:model="newsType" class="w-1/2 px-4 py-2 border rounded">
                    <option value="" class="text-gray-500" disabled>Select news type</option>
                    <option value="national">National</option>
                    <option value="local">Local</option>
                </select>

            </div>
            {{-- COUNTY --}}
            <div class=" flex flex-col items-center justify-center gap-2 h-24 rounded-sm bg-gray-50 dark:bg-gray-800">
                <label for="county">County</label>
                <p class="text-green"> {{$selectedCounty}}</p>
                <input id="county" type="text" wire:model.live="searchCounty"
                    placeholder="Search for a county..." class="w-3/4 px-4 py-2 border rounded" />

                @if(!empty($counties))

                    <ul class="w-3/4 mx-auto mt-2 bg-white border rounded shadow dark:bg-gray-700 dark:border-gray-600">
                        @foreach($counties as $county)
                            <li   wire:click="selectCounty('{{ $county->id }}','{{ $county->name }}')"
                                class="px-4 py-2 border-b last:border-b-0 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer">
                                {{ $county->name }}
                            </li>
                        @endforeach
                    </ul>
                @elseif(!empty($searchCounty))
                    <p class="w-3/4 mx-auto mt-2 text-gray-500 dark:text-gray-300">No counties found for
                        "{{ $searchCounty }}".</p>
                @endif
            </div>

            {{-- CONSTITUENCY --}}
            <div class="flex flex-col items-center gap-2 rounded-sm bg-gray-50 dark:bg-gray-800 py-4 relative w-full">

                <label for="constituency" class="text-sm font-medium text-gray-700 dark:text-gray-300">Constituency</label>
                <p class="text-green"> {{$selectedConstituency}}</p>
                <!-- Input & Dropdown container -->
                <div class="relative w-3/4">
                    <input
                        id="constituency"
                        type="text"
                        wire:model.live="searchConstituency"
                        placeholder="Search for a constituency..."
                        class="w-full px-4 py-2 border rounded"
                    />

                    <!-- Dropdown -->
                    @if(!empty($constituencies))
                        <ul class="absolute z-10 w-full bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 mt-1 rounded shadow max-h-60 overflow-y-auto">
                            @foreach($constituencies as $constituency)
                                <li
                                    wire:click="selectConstituency('{{ $constituency->id }}','{{$constituency->name}}')"
                                    class="px-4 py-2 border-b border-gray-200 dark:border-gray-600 last:border-b-0 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer transition-colors
                                        {{ $selectedConstituencyId == $constituency->id ? 'bg-blue-50 dark:bg-blue-800' : '' }}"
                                >
                                    {{ $constituency->name }}
                                </li>
                            @endforeach
                        </ul>
                    @elseif(!empty($searchConstituency))
                        <p class="mt-1 text-sm text-gray-500 dark:text-gray-300">
                            No constituencies found for "{{ $searchConstituency }}".
                        </p>
                    @endif
                </div>

            </div>


            {{-- SUBCOUNTY --}}
            <div class="flex flex-col items-center justify-center h-24 gap-2 rounded-sm bg-gray-50 dark:bg-gray-800">
                <label for="subcounty">Subcounty</label>
                <p class="text-green">{{$selectedSubcounty}}</p>
                <input id="subcounty" type="text" wire:model.live="searchSubcounty"
                    placeholder="Search for a subcounty..." class="w-3/4 px-4 py-2 border rounded" />

                @if(!empty($subcounties))
                    <ul class="w-3/4 mx-auto mt-2 bg-white border rounded shadow dark:bg-gray-700 dark:border-gray-600">
                        @foreach($subcounties as $subcounty)
                            <li  wire:click="selectSubcounty('{{ $subcounty->id }}','{{ $subcounty->name }}')"
                                class="px-4 py-2 border-b last:border-b-0 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer">
                                {{ $subcounty->name }}
                            </li>
                        @endforeach
                    </ul>
                @elseif(!empty($searchSubcounty))
                    <p class="w-3/4 mx-auto mt-2 text-gray-500 dark:text-gray-300">No subcounties found for
                        "{{ $searchSubcounty }}".</p>
                @endif
            </div>


        </div>
        <div class="flex  flex-col items-center justify-center h-48 mb-4 rounded-sm bg-gray-50 dark:bg-gray-800">
            <label for="title">Title</label>
           <textarea name="title" id="title" wire:wire:model="title" cols="1" class="w-3/4 px-4 py-2 border rounded"></textarea>
        </div>
        <div class="flex flex-col items-center justify-center h-48 mb-4 rounded-sm bg-gray-50 dark:bg-gray-800">
            <label for="image">Image</label>
          <input type="file" name="image" id="image" wire:model="image" class="w-3/4 px-4 py-2 border rounded">
        </div>
        <div class="flex  flex-col items-center justify-center h-48 mb-4 rounded-sm bg-gray-50 dark:bg-gray-800">
            <label for="title">Title</label>
           <textarea name="title" id="title" wire:wire:model="content" cols="12" class="w-3/4 px-4 py-2 border rounded"></textarea>
        </div>

        <button
        type="submit"
        wire:loading.attr="disabled"
        class="px-4 py-2 bg-black text-black rounded hover:bg-blue-700 flex items-center justify-center gap-2"
    >
        <span wire:loading.remove wire:target="createNews">Upload News</span>
        <span wire:loading wire:target="createNews">Uploading...</span>
    </button>
    </form>
    </div>

</div>


{{-- <div>
    <input
    type="text"
    wire:model.live="searchCounty"
    placeholder="Type something..."
>
@if($searchCounty)
<div class="mt-4">
    You typed: <strong>{{ $searchCounty }}</strong>
    @foreach ($counties as $county )
    <span>{{$county['name']}}</span>
    @endforeach
</div>
@endif
</div> --}}