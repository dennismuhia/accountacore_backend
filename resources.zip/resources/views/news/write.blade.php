<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Constituency') }}
        </h2>
    </x-slot>
    @if(session('success'))
        <div class="p-2 bg-green-200 text-green-800 rounded mb-2">
            {{ session('success') }}
        </div>
    @endif

@livewire('news.write-news')

</x-app-layout>